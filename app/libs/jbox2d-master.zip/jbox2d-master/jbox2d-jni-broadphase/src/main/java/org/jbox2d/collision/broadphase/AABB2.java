package org.jbox2d.collision.broadphase;

public class AABB2 {
  float lx;
  float ly;
  float ux;
  float uy;
}
